import type { WorkspaceId } from "./workspaces";

/**
 * DEMO ONLY. This is a keyword matcher that stands in for the real router.
 * When a model is connected, replace `demoRoute` with a call to a server-side
 * route handler (see README, "Connecting the router"). Keep the return shape.
 */
export interface RouteResult {
  workspace: WorkspaceId;
  matched: string | null;
}

const RULES: { id: WorkspaceId; words: string[] }[] = [
  { id: "code", words: ["code", "bug", "debug", "function", "api", "react", "python", "typescript", "error", "refactor", "sql", "script", "component", "test"] },
  { id: "image", words: ["image", "logo", "picture", "illustration", "poster", "draw", "render", "photo", "artwork", "wallpaper"] },
  { id: "automation", words: ["automate", "automation", "workflow", "schedule", "every", "remind", "email me", "sync", "notify", "when a"] },
  { id: "learn", words: ["learn", "teach", "study", "quiz", "lesson", "course", "practice", "beginner", "explain how", "basics"] },
];

export function demoRoute(prompt: string): RouteResult {
  const text = prompt.toLowerCase();
  let best: RouteResult = { workspace: "chat", matched: null };
  let bestScore = 0;
  for (const rule of RULES) {
    const hits = rule.words.filter((w) => text.includes(w));
    if (hits.length > bestScore) {
      bestScore = hits.length;
      best = { workspace: rule.id, matched: hits[0] };
    }
  }
  return best;
}
