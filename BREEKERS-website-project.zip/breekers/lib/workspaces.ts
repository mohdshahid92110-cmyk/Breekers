import {
  Code2,
  GraduationCap,
  ImagePlus,
  LayoutDashboard,
  MessageSquareText,
  Workflow,
  type LucideIcon,
} from "lucide-react";

export type WorkspaceId = "chat" | "code" | "image" | "automation" | "learn";
export type AnyWorkspaceId = WorkspaceId | "hub";

export interface Workspace {
  id: AnyWorkspaceId;
  name: string;
  short: string;
  description: string;
  href: string;
  icon: LucideIcon;
  color: string;
  tags: string[];
  /** Capabilities this workspace will expose once backends are connected. */
  plannedTools: string[];
  emptyTitle: string;
  emptyBody: string;
  starters: string[];
  placeholder: string;
}

export const HUB: Workspace = {
  id: "hub",
  name: "Central assistant",
  short: "Home",
  description: "One place to ask for anything. It decides which workspace should handle the request.",
  href: "/app",
  icon: LayoutDashboard,
  color: "#8B5CF6",
  tags: [],
  plannedTools: ["Intent detection", "Hand-off to workspaces", "Shared context across workspaces"],
  emptyTitle: "Ask for anything",
  emptyBody:
    "Describe what you want to get done. The central assistant will suggest the workspace that fits best.",
  starters: [
    "Fix the bug in my React component",
    "Explain how neural networks learn",
    "Every Friday, email me a summary of my notes",
    "Design a logo concept for a coffee brand",
  ],
  placeholder: "What do you want to get done?",
};

export const WORKSPACES: Workspace[] = [
  {
    id: "chat",
    name: "Breekers AI",
    short: "Chat",
    description: "Conversation and research in one thread. Ask questions, compare options, draft and refine.",
    href: "/app/chat",
    icon: MessageSquareText,
    color: "#8B5CF6",
    tags: ["Conversation", "Research", "Writing"],
    plannedTools: ["Streaming chat", "Web research with sources", "Document Q&A", "Saved conversations"],
    emptyTitle: "Start a conversation",
    emptyBody: "Ask a question, paste a draft, or think a problem through out loud.",
    starters: [
      "Summarise the pros and cons of remote-first teams",
      "Help me outline a talk on product strategy",
      "Compare three ways to learn Spanish quickly",
    ],
    placeholder: "Ask or research anything",
  },
  {
    id: "code",
    name: "Breekers Code",
    short: "Code",
    description: "Write, explain and debug code. Paste an error and get the cause, not just a guess.",
    href: "/app/code",
    icon: Code2,
    color: "#22D3EE",
    tags: ["Debugging", "Refactoring", "Explanations"],
    plannedTools: ["Code generation", "Stack trace analysis", "Repository context", "Diff review"],
    emptyTitle: "Paste some code or an error",
    emptyBody: "Share the snippet and what you expected to happen. Include the error message if there is one.",
    starters: [
      "Why does my useEffect run twice?",
      "Convert this callback code to async/await",
      "Write unit tests for a date-formatting helper",
    ],
    placeholder: "Describe the bug or paste code",
  },
  {
    id: "image",
    name: "Breekers Image Studio",
    short: "Images",
    description: "Turn a written idea into visuals. Explore variations and refine the ones you like.",
    href: "/app/image",
    icon: ImagePlus,
    color: "#C084FC",
    tags: ["Generation", "Variations", "Style control"],
    plannedTools: ["Text-to-image", "Variations", "Style presets", "Asset library"],
    emptyTitle: "Describe an image",
    emptyBody: "Say what is in the scene, the mood and the style. Your results will appear here.",
    starters: [
      "A glass hexagon floating above a violet nebula",
      "Minimal logo for a mountain bike brand, flat colours",
      "Isometric illustration of a tiny home office",
    ],
    placeholder: "Describe the image you want",
  },
  {
    id: "automation",
    name: "Breekers Automation",
    short: "Automate",
    description: "Describe a repeating task in plain language and turn it into a workflow you can review.",
    href: "/app/automation",
    icon: Workflow,
    color: "#6366F1",
    tags: ["Workflows", "Schedules", "Integrations"],
    plannedTools: ["Workflow planner", "Scheduler", "App integrations", "Run history"],
    emptyTitle: "No automations yet",
    emptyBody: "Describe a task you repeat, and it will be drafted as steps you can approve before anything runs.",
    starters: [
      "Every Monday at 9, summarise new support tickets",
      "When a form is submitted, add a row to my spreadsheet",
      "Remind me to review invoices on the last day of each month",
    ],
    placeholder: "Describe what should happen, and when",
  },
  {
    id: "learn",
    name: "Breekers Learn",
    short: "Learn",
    description: "A patient tutor. Build a study plan, get concepts explained simply, and test yourself.",
    href: "/app/learn",
    icon: GraduationCap,
    color: "#67E8F9",
    tags: ["Study plans", "Explanations", "Practice"],
    plannedTools: ["Personalised study plans", "Step-by-step explanations", "Quizzes", "Progress tracking"],
    emptyTitle: "What do you want to learn?",
    emptyBody: "Tell it the topic and what you already know. It will start from there.",
    starters: [
      "Teach me the basics of probability",
      "Quiz me on the French Revolution",
      "Make a 4-week plan to learn SQL",
    ],
    placeholder: "Name a topic or paste your notes",
  },
];

export const ALL_WORKSPACES: Workspace[] = [HUB, ...WORKSPACES];

export function getWorkspace(id: string): Workspace | undefined {
  return ALL_WORKSPACES.find((w) => w.id === id);
}
