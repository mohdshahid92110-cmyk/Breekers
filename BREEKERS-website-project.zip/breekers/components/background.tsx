/** Decorative animated backdrop. Pure CSS, no client JS. */
export function Background() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink">
      <div className="grid-fade absolute inset-0" />
      <div className="absolute -left-40 top-[-10%] h-[34rem] w-[34rem] animate-drift rounded-full bg-brand-violet/25 blur-[120px]" />
      <div className="absolute -right-32 top-[20%] h-[30rem] w-[30rem] animate-drift-slow rounded-full bg-brand-cyan/15 blur-[120px]" />
      <div className="absolute bottom-[-20%] left-1/3 h-[30rem] w-[30rem] animate-drift rounded-full bg-brand-indigo/20 blur-[130px]" />
    </div>
  );
}
