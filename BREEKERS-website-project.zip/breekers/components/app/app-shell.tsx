"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ALL_WORKSPACES } from "@/lib/workspaces";

function SideNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav aria-label="Workspaces" className="flex flex-col gap-1">
      {ALL_WORKSPACES.map((w) => {
        const active = pathname === w.href;
        const Icon = w.icon;
        return (
          <Link
            key={w.id}
            href={w.href}
            onClick={onNavigate}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
              active ? "bg-white/10 text-white" : "text-mute hover:bg-white/5 hover:text-white",
            )}
          >
            <Icon className="h-4 w-4" style={{ color: w.color }} aria-hidden />
            {w.id === "hub" ? "Home" : w.name.replace("Breekers ", "")}
          </Link>
        );
      })}
    </nav>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => setOpen(false), [pathname]);

  return (
    <div className="flex min-h-screen">
      <aside className="glass sticky top-0 hidden h-screen w-64 shrink-0 flex-col gap-6 border-y-0 border-l-0 p-4 md:flex">
        <Link href="/" className="px-2 pt-2" aria-label="Breekers home">
          <Logo />
        </Link>
        <SideNav />
        <p className="mt-auto px-2 text-xs leading-relaxed text-mute/80">
          Preview build. No AI model is connected, so replies are placeholders.
        </p>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="glass sticky top-0 z-30 flex h-14 items-center justify-between border-x-0 border-t-0 px-4 md:hidden">
          <Link href="/" aria-label="Breekers home"><Logo size={26} /></Link>
          <Button
            variant="ghost"
            size="icon"
            aria-label={open ? "Close workspace menu" : "Open workspace menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </header>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="glass sticky top-14 z-20 border-x-0 p-3 md:hidden"
            >
              <SideNav onNavigate={() => setOpen(false)} />
            </motion.div>
          )}
        </AnimatePresence>

        <main id="main" className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-6 sm:px-6">
          <Badge className="mb-4 self-start border-brand-cyan/30 text-brand-cyan">Demo mode: no AI connected</Badge>
          {children}
        </main>
      </div>
    </div>
  );
}
