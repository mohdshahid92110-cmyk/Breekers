"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, SendHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { demoRoute } from "@/lib/router";
import { getWorkspace, type Workspace } from "@/lib/workspaces";

interface Message {
  id: number;
  role: "user" | "system";
  text: string;
  link?: { href: string; label: string };
}

function buildReply(w: Workspace, prompt: string): Omit<Message, "id" | "role"> {
  if (w.id === "hub") {
    const r = demoRoute(prompt);
    const target = getWorkspace(r.workspace)!;
    return {
      text: r.matched
        ? `Demo routing: “${r.matched}” suggests ${target.name}. A real assistant would hand this request over with its context.`
        : `Demo routing: no specific match, so ${target.name} is the default. A real assistant would decide using the full request.`,
      link: { href: target.href, label: `Open ${target.name}` },
    };
  }
  return {
    text: `No AI model is connected yet, so there is no real answer to “${prompt.slice(0, 80)}”. Once connected, ${w.name} would use: ${w.plannedTools.join(", ")}.`,
  };
}

export function WorkspaceView({ workspaceId }: { workspaceId: string }) {
  const w = getWorkspace(workspaceId)!;
  const [messages, setMessages] = useState<Message[]>([]);
  const [value, setValue] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const Icon = w.icon;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages]);

  const send = (text: string) => {
    const prompt = text.trim();
    if (!prompt) return;
    const id = Date.now();
    setMessages((m) => [
      ...m,
      { id, role: "user", text: prompt },
      { id: id + 1, role: "system", ...buildReply(w, prompt) },
    ]);
    setValue("");
  };

  return (
    <div className="flex flex-1 flex-col">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: `${w.color}22`, color: w.color }}>
          <Icon className="h-5 w-5" aria-hidden />
        </span>
        <div>
          <h1 className="font-display text-xl font-semibold">{w.name}</h1>
          <p className="text-sm text-mute">{w.description}</p>
        </div>
      </div>

      <div className="mt-6 flex-1" role="log" aria-live="polite" aria-label="Conversation">
        {messages.length === 0 ? (
          <div className="glass glow-border flex flex-col items-center rounded-3xl px-6 py-12 text-center">
            <span className="grid h-14 w-14 place-items-center rounded-2xl" style={{ background: `${w.color}22`, color: w.color }}>
              <Icon className="h-7 w-7" aria-hidden />
            </span>
            <h2 className="mt-5 font-display text-lg font-semibold">{w.emptyTitle}</h2>
            <p className="mt-2 max-w-md text-mute">{w.emptyBody}</p>
            <ul className="mt-6 flex flex-wrap justify-center gap-2">
              {w.starters.map((s) => (
                <li key={s}>
                  <button
                    type="button"
                    onClick={() => setValue(s)}
                    className="rounded-full border border-white/10 px-3 py-1.5 text-sm text-mute transition-colors hover:border-brand-cyan/40 hover:text-white"
                  >
                    {s}
                  </button>
                </li>
              ))}
            </ul>
            <div className="mt-8 w-full border-t border-white/10 pt-5 text-left">
              <p className="text-sm font-medium">Planned for this workspace</p>
              <ul className="mt-2 grid gap-x-6 gap-y-1 text-sm text-mute sm:grid-cols-2">
                {w.plannedTools.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </div>
          </div>
        ) : (
          <ul className="flex flex-col gap-3">
            <AnimatePresence initial={false}>
              {messages.map((m) => (
                <motion.li
                  key={m.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={
                    m.role === "user"
                      ? "max-w-[85%] self-end rounded-2xl rounded-br-md bg-gradient-to-r from-brand-violet to-brand-indigo px-4 py-3"
                      : "glass max-w-[90%] self-start rounded-2xl rounded-bl-md px-4 py-3 text-sm leading-relaxed"
                  }
                >
                  {m.text}
                  {m.link && (
                    <Link href={m.link.href} className="mt-2 flex items-center gap-1 text-brand-cyan hover:underline">
                      {m.link.label} <ArrowRight className="h-4 w-4" aria-hidden />
                    </Link>
                  )}
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}
        <div ref={endRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(value);
        }}
        className="glass glow-border sticky bottom-4 mt-6 flex items-end gap-2 rounded-3xl p-2"
      >
        <label htmlFor="composer" className="sr-only">{w.placeholder}</label>
        <textarea
          id="composer"
          rows={1}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send(value);
            }
          }}
          placeholder={w.placeholder}
          className="max-h-40 min-h-[2.75rem] flex-1 resize-none bg-transparent px-3 py-2.5 text-sm placeholder:text-mute/70 focus:outline-none"
        />
        <Button type="submit" size="icon" aria-label="Send" disabled={!value.trim()}>
          <SendHorizontal className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}
