import { notFound } from "next/navigation";
import { WorkspaceView } from "@/components/app/workspace-view";
import { WORKSPACES, getWorkspace } from "@/lib/workspaces";

export function generateStaticParams() {
  return WORKSPACES.map((w) => ({ workspace: w.id }));
}

export default async function WorkspacePage({ params }: { params: Promise<{ workspace: string }> }) {
  const { workspace } = await params;
  const w = getWorkspace(workspace);
  if (!w || w.id === "hub") notFound();
  return <WorkspaceView workspaceId={w.id} />;
}
