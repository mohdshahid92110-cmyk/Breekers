import { WorkspaceView } from "@/components/app/workspace-view";

export default function HubPage() {
  return <WorkspaceView workspaceId="hub" />;
}
