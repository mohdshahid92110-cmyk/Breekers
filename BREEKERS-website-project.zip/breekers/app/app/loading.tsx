export default function Loading() {
  return (
    <div role="status" className="space-y-4">
      <div className="h-10 w-64 animate-pulse rounded-xl bg-white/5" />
      <div className="h-64 animate-pulse rounded-3xl bg-white/5" />
      <span className="sr-only">Loading workspace</span>
    </div>
  );
}
