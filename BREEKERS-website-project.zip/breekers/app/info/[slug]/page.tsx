import Link from "next/link";
import { notFound } from "next/navigation";
import { Footer } from "@/components/footer";
import { Navbar } from "@/components/navbar";

const PAGES: Record<string, { title: string; body: string }> = {
  about: {
    title: "About Breekers",
    body: "Breekers is an early-stage project building one AI workspace for conversation, coding, images, automation and learning. This page is a placeholder until the story is written.",
  },
  contact: {
    title: "Contact",
    body: "A contact form and support address will appear here. Nothing on this page sends a message yet.",
  },
  privacy: {
    title: "Privacy Policy",
    body: "Draft placeholder. A real privacy policy, reviewed by a qualified professional, must be published before Breekers collects any personal data.",
  },
  terms: {
    title: "Terms",
    body: "Draft placeholder. Terms of service, reviewed by a qualified professional, must be published before Breekers launches.",
  },
};

export function generateStaticParams() {
  return Object.keys(PAGES).map((slug) => ({ slug }));
}

export default async function InfoPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const page = PAGES[slug];
  if (!page) notFound();
  return (
    <>
      <Navbar />
      <main id="main" className="mx-auto min-h-[60vh] max-w-2xl px-5 pb-20 pt-36">
        <h1 className="font-display text-4xl font-semibold tracking-tight">{page.title}</h1>
        <p className="mt-5 text-lg leading-relaxed text-mute">{page.body}</p>
        <Link href="/" className="mt-8 inline-block text-brand-cyan underline-offset-4 hover:underline">
          Back to home
        </Link>
      </main>
      <Footer />
    </>
  );
}
